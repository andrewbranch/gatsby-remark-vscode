# Oceanic Plus

Oceanic Plus is a color scheme based on the popular Oceanic Next, with enhanced VSCode-specific enhancements targeting the workspace and other UI elements.

Inspiration taken from One Dark, Ayu, and of course Oceanic Next!

![Workspace](https://raw.githubusercontent.com/marcoms/oceanic-plus/master/screenshot-workspace.png)

![Syntax](https://raw.githubusercontent.com/marcoms/oceanic-plus/master/screenshot-syntax.png)

## Credits

- [Oceanic Next Color Scheme](https://github.com/voronianski/oceanic-next-color-scheme)
- [Oceanic Next Italic](https://github.com/Bloemert/oceanic-next-italic)
