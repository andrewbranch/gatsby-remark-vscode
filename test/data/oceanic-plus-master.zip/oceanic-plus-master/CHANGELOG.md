# Changelog

## 2018-12-31

- Improve contrast of context menus with editor and line highlight
- Add ruler color to match indent guide

## 2017-09-22

- Added notification colors
- Added remaining status bar colors
- Added titlebar colors for macOS
- Altered cursor foreground color

## 2017-09-19

> Initial release ported from [Oceanic Next Italic](https://github.com/Bloemert/oceanic-next-italic)

- Added workspace/user interface colors
- Made function definition parameters italic
- Set variable color to a more visible shade
